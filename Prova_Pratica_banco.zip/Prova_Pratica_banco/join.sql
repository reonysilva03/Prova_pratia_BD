SELECT 
    t.nome_turma,
    t.periodo_letivo,
    a.nome AS aluno,
    p.nome AS professor,
    d.nome_disciplina
FROM instituicao.Turma t
JOIN instituicao.Aluno a ON t.idaluno = a.idaluno
JOIN instituicao.Professor p ON t.idprofessor = p.idprofessor
JOIN instituicao.Disciplina d ON t.iddisciplina = d.iddisciplina;