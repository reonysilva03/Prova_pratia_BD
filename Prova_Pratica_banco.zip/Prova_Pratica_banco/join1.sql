SELECT 
    t.nome_turma,
    a.nome AS aluno
FROM instituicao.Turma t
JOIN instituicao.Aluno a ON t.idaluno = a.idaluno
WHERE a.nome = 'João Silva';