INSERT INTO instituicao.Aluno (nome, matricula) VALUES
('João Silva', '2023001'),
('Maria Souza', '2023002'),
('Carlos Lima', '2023003'),
('Ana Costa', '2023004'),
('Pedro Santos', '2023005');

INSERT INTO instituicao.Professor (nome, matricula) VALUES
('Marcos Rocha', 'P001'),
('Ana Lima', 'P002'),
('Carlos Mendes', 'P003');

INSERT INTO instituicao.Disciplina (nome_disciplina, carga_horaria) VALUES
('Matemática', '60h'),
('Programação', '80h'),
('Banco de Dados', '70h');

INSERT INTO instituicao.Turma (nome_turma, periodo_letivo, idaluno, idprofessor, iddisciplina) VALUES
('Turma A', '2026.1', 1, 1, 1),
('Turma B', '2026.1', 2, 2, 2),
('Turma C', '2026.1', 3, 3, 3),
('Turma D', '2026.2', 4, 1, 2),
('Turma E', '2026.2', 5, 2, 1);