SELECT * FROM instituicao.Aluno
WHERE nome = 'João Silva';