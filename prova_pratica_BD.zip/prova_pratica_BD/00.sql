INSERT INTO Aluno (nome, matricula) VALUES
('João Silva', '2023001'),
('Maria Souza', '2023002'),
('Carlos Lima', '2023003'),
('Ana Costa', '2023004'),
('Pedro Santos', '2023005');

INSERT INTO Professor (nome, matricula) VALUES
('Marcos Rocha', 'P001'),
('Ana Lima', 'P002'),
('Carlos Mendes', 'P003');

INSERT INTO Disciplina (nome_disciplina, carga_horaria, id_professor) VALUES
('Banco de Dados', 60, 1),
('Programação', 80, 2),
('Engenharia de Software', 70, 3);

INSERT INTO Turma (nome_turma, periodo_letivo, id_aluno, id_disciplina) VALUES
('ADS 3º Período', '2026.1', 1, 1),
('ADS 3º Período', '2026.1', 2, 1),
('ADS 3º Período', '2026.1', 3, 2),
('ADS 3º Período', '2026.1', 4, 2),
('ADS 3º Período', '2026.1', 5, 3);