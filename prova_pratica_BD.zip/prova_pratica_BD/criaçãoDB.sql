-- MySQL Workbench Synchronization
-- Generated: 2026-04-15 21:41
-- Model: New Model
-- Version: 1.0
-- Project: Name of the project
-- Author: Reony

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

CREATE SCHEMA IF NOT EXISTS `instituição` DEFAULT CHARACTER SET utf8 ;

CREATE TABLE IF NOT EXISTS `instituição`.`Aluno` (
  `idaluno` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `matricula` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idaluno`),
  UNIQUE INDEX `idaluno_UNIQUE` (`idaluno` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `instituição`.`Turma` (
  `idturma` INT(11) NOT NULL AUTO_INCREMENT,
  `nome_turma` VARCHAR(45) NOT NULL,
  `periodo_letivo` VARCHAR(45) NOT NULL,
  `idaluno` INT(11) NOT NULL,
  `idprofessor` INT(11) NOT NULL,
  `iddisciplina` INT(11) NOT NULL,
  PRIMARY KEY (`idturma`),
  UNIQUE INDEX `idturma_UNIQUE` (`idturma` ASC) VISIBLE,
  INDEX `FK_turma_aluno_idx` (`idaluno` ASC) VISIBLE,
  INDEX `FK_turma_professor_idx` (`idprofessor` ASC) VISIBLE,
  INDEX `FK_turma_disciplina_idx` (`iddisciplina` ASC) VISIBLE,
  CONSTRAINT `FK_turma_aluno`
    FOREIGN KEY (`idaluno`)
    REFERENCES `instituição`.`Aluno` (`idaluno`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_turma_professor`
    FOREIGN KEY (`idprofessor`)
    REFERENCES `instituição`.`Professor` (`idprofessor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_turma_disciplina`
    FOREIGN KEY (`iddisciplina`)
    REFERENCES `instituição`.`Disciplina` (`iddisciplina`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `instituição`.`Professor` (
  `idprofessor` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `matricula` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idprofessor`),
  UNIQUE INDEX `idprofessor_UNIQUE` (`idprofessor` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `instituição`.`Disciplina` (
  `iddisciplina` INT(11) NOT NULL AUTO_INCREMENT,
  `nome_disciplina` VARCHAR(45) NOT NULL,
  `carga_horaria` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`iddisciplina`),
  UNIQUE INDEX `iddisciplina_UNIQUE` (`iddisciplina` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
